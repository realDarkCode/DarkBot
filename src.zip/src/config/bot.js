const config = {
  development: {
    developerID: "734694074304561162",
  },
};
module.exports = config;
